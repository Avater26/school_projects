module.exports = function (app) {
    app.locals.site = {
        name: "Magnus Spilbiks"
    }
}