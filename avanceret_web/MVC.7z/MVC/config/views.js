module.exports = function (app) {
    app.set("views", "MVC/views");
    app.set("view engine", "ejs");
}